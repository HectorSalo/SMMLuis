package com.example.hchirinos.elmejorprecio;

public class VistaGridList {

    public static final int List = 1;
    public static final int Grid = 0;

    public static int visualizacion = Grid;

}
